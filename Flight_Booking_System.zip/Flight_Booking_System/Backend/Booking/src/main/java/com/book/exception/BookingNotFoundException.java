package com.book.exception;

public class BookingNotFoundException extends Exception {

	public BookingNotFoundException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public BookingNotFoundException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

}