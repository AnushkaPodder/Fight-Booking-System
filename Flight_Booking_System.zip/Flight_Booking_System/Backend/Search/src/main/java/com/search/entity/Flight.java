package com.search.entity;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Size;

import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.Transient;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.format.annotation.DateTimeFormat;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Data
@NoArgsConstructor
//@AllArgsConstructor(staticName = "build")
@AllArgsConstructor
@Setter
@Getter
@Document(collection = "search")
public class Flight {
	
	
    @Id
	private long id;
	
    @NotEmpty(message="Please Enter Flight Number")
    @Size(min = 4, message = "Flight Number must be minium of 4 Character")
	private String code;
    
    @NotEmpty(message="Please Enter Origin")
	String from;
    
    @NotEmpty(message="Please Enter Destination")
	String to;
    
    @NotEmpty(message="Please Enter Price") //
  	int price;
    
    @NotEmpty(message="Please Enter arrival time") //
  	String arrivalTime;
    
    @NotEmpty(message="Please Enter depart time") //
  	String departTime;
    
    @DateTimeFormat
	String depart;
	
//	public Flight() {
//		super();
//	}

	public Flight(long id, String code, String from, String to, int price, String arrivalTime, String departTime, String depart) {
		super();
		this.id = id;
		this.code = code;
		this.from = from;
		this.to = to;
		this.price = price;
		this.arrivalTime = arrivalTime;
		this.departTime = departTime;
		this.depart = depart;
	}

	public Flight() {
		// TODO Auto-generated constructor stub
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getFrom() {
		return from;
	}

	public void setFrom(String from) {
		this.from = from;
	}

	public String getTo() {
		return to;
	}

	public void setTo(String to) {
		this.to = to;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public String getArrivalTime() {
		return arrivalTime;
	}

	public void setArrivalTime(String arrivalTime) {
		this.arrivalTime = arrivalTime;
	}

	public String getDepartTime() {
		return departTime;
	}

	public void setDepartTime(String departTime) {
		this.departTime = departTime;
	}

	public String getDepart() {
		return depart;
	}

	public void setDepart(String depart) {
		this.depart = depart;
	}

	@Override
	public String toString() {
		return "Flight [id=" + id + ", code=" + code + ", from=" + from + ", to=" + to + ", price=" + price
				+ ", arrivalTime=" + arrivalTime + ", departTime=" + departTime + ", depart=" + depart + "]";
	}
}

	