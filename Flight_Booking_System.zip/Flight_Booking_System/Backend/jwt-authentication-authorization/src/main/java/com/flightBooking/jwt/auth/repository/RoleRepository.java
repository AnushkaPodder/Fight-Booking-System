package com.flightBooking.jwt.auth.repository;

import java.util.Optional;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.flightBooking.jwt.auth.models.ERole;
import com.flightBooking.jwt.auth.models.Role;

public interface RoleRepository extends MongoRepository<Role, String> {
  Optional<Role> findByName(ERole name);
}
