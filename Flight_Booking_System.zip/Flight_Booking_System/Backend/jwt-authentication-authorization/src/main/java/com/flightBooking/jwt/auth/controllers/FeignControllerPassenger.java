package com.flightBooking.jwt.auth.controllers;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.flightBooking.jwt.auth.exception.NoProperDataException;
import com.flightBooking.jwt.auth.exception.PassengerNotFoundException;
import com.flightBooking.jwt.auth.models.PassengerDetails;
import com.flightBooking.jwt.auth.util.FeignUtilPassenger;


@RestController

@RequestMapping("/api/v2")
public class FeignControllerPassenger {
	

	@Autowired
	private FeignUtilPassenger feignPassenger;
	

	@GetMapping("/allPassengers") 
	@PreAuthorize(" hasRole('ADMIN')")
	public ResponseEntity<List<PassengerDetails>> getAllPassenger(@RequestHeader("Authorization") String token) throws PassengerNotFoundException
	{
		
		return feignPassenger.getAllPassenger(token);
		
	}
	
	@GetMapping("/getPassenger/{id}")
	@PreAuthorize("hasRole('USER') or hasRole('ADMIN')")
	public ResponseEntity<PassengerDetails> getPassengerById(@Valid @RequestHeader("Authorization") String token,@PathVariable  Integer id) throws PassengerNotFoundException{
		return feignPassenger.getPassengerById(token,id);
	}
	
	@PostMapping("/addPassenger") 
	@PreAuthorize("hasRole('USER') or hasRole('ADMIN')")
	public ResponseEntity<PassengerDetails> addPassenger(@Valid @RequestBody PassengerDetails passenger)  throws NoProperDataException
	{
		
		return feignPassenger.addPassenger(passenger);
	}
	
	@PutMapping("/updatePassenger/{id}")
	@PreAuthorize("hasRole('USER') or hasRole('ADMIN')")
	public ResponseEntity<PassengerDetails> updatePassenger(@Valid @RequestBody PassengerDetails passenger)  throws NoProperDataException
	{
		
		return feignPassenger.updatePassenger(passenger);
	}


	@DeleteMapping(path="/deletePassenger/{id}")
	@PreAuthorize("hasRole('ADMIN')")
	public ResponseEntity<String> deletePassenger(@Valid @RequestHeader("Authorization") String token,@PathVariable int id) throws PassengerNotFoundException {
			return feignPassenger.deletePassenger(token,id);
	}

}

