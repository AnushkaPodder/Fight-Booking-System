package com.flightBooking.jwt.auth.exception;

@SuppressWarnings("serial")
public class RoleNotFoundException extends Exception{
	
	public RoleNotFoundException(String mm)
	{
		super(mm);
	}

}

