package com.flightBooking.jwt.auth.util;


import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;

import com.flightBooking.jwt.auth.models.Flight;


@FeignClient(value="Search-Service",url="http://localhost:8089/search")
public interface ClientUtilSearch {
	
	@GetMapping("/") 
	public ResponseEntity<List<Flight>> getAllFlight(@RequestHeader("Authorization") String token);
	

	@PostMapping("/") 
	public ResponseEntity<Flight> addFlight(@RequestBody Flight flight);


	@DeleteMapping(path="/delete/{id}")
	public ResponseEntity<String> deleteFlight(@RequestHeader("Authorization") String token,@PathVariable int id);
	

}

