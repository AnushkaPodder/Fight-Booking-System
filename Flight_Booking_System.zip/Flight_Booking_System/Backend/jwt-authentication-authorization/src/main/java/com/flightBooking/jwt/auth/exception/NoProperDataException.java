package com.flightBooking.jwt.auth.exception;

@SuppressWarnings("serial")
public class NoProperDataException extends Exception {

	public NoProperDataException(String message) {
		super(message);

	}

	
}
