package com.flightBooking.jwt.auth.models;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Size;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.format.annotation.DateTimeFormat;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


	@Data
	@AllArgsConstructor
	@NoArgsConstructor
	@Document(collection="order")
	public class Flight {
		
		public static final String SEQUENCE_NAME = "book_sequence";
		@Id
		private long id;
		
	    @NotEmpty(message="Please Enter Flight Number")
	    @Size(min = 4, message = "Flight Number must be minium of 4 Character")
		private String code;
	    
	    @NotEmpty(message="Please Enter Origin")
		String from;
	    
	    @NotEmpty(message="Please Enter Destination")
		String to;
	    
	    @NotEmpty(message="Please Enter Price") //
	  	int price;
	    
	    @NotEmpty(message="Please Enter arrival time") //
	  	String arrivalTime;
	    
	    @NotEmpty(message="Please Enter depart time") //
	  	String departTime;
	    
	    @DateTimeFormat
		String depart;
		public void setFlightOrderId(int sequenceNumberForOrder) {
			// TODO Auto-generated method stub
			this.id = sequenceNumberForOrder;
		}
}
