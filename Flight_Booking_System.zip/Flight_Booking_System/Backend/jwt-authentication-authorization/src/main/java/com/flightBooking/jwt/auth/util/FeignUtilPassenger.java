package com.flightBooking.jwt.auth.util;

import java.util.List;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestHeader;

import com.flightBooking.jwt.auth.models.PassengerDetails;

@FeignClient(value="Passenger-Service",url="http://localhost:9093/api/v2")
public interface FeignUtilPassenger {
	
	@GetMapping("/allPassenger") 
	public ResponseEntity<List<PassengerDetails>> getAllPassenger(@RequestHeader("Authorization") String token);
	
	
	@GetMapping("/getPassenger/{id}")
	
	public ResponseEntity<PassengerDetails> getPassengerById(@RequestHeader("Authorization") String token, int id);
	
	
	@PostMapping("/addPassenger") 
	public ResponseEntity<PassengerDetails> addPassenger(PassengerDetails passenger);

	@PutMapping("/updatePassenger")
	public ResponseEntity<PassengerDetails> updatePassenger(PassengerDetails passenger);
	
	@DeleteMapping(path="/deletePassenger/{id}")
	public ResponseEntity<String> deletePassenger(@RequestHeader("Authorization") String token,int id);


}

