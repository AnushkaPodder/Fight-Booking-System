package com.flightBooking.jwt.auth.models;

public enum ERole {
  ROLE_USER,
  ROLE_ADMIN
}
