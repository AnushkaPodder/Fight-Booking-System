package com.order.exception;

@SuppressWarnings("serial")
public class NoProperDataException extends Exception {

	public NoProperDataException(String msg) {
		super(msg);
		
	}

}
