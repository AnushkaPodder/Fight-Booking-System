package com.order.service;

import java.util.List;


import com.order.exception.NoProperDataException;
import com.order.exception.OrderNotFoundException;
import com.order.model.Order;


public interface OrderService {
	public  List<Order> getAllOrders() throws  OrderNotFoundException;
	public Order getOrderById( int id) throws OrderNotFoundException;
	public Order addOrders( Order order)  throws NoProperDataException;
	public String deleteOrder( int id) throws OrderNotFoundException;
}
